package com.dts.crsm.model;

public class Brand {
   
	private int brandID;
	private String brandName;
	private String brandDesc;
	
	public int getBrandID() {
		return brandID;
	}
	
	public void setBrandID(int brandID) {
		this.brandID = brandID;
	}
	
	public String getBrandName() {
		return brandName;
	}
	
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	
	public String getBrandDesc() {
		return brandDesc;
	}
	
	public void setBrandDesc(String brandDesc) {
		this.brandDesc = brandDesc;
	}
}
